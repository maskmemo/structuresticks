import { world, system} from "@minecraft/server";

const STRUCTURE_WAND_ID = "structurestick:save_structure";
const BLAZE_WAND_ID = "structurestick:load_structure";
const VOID_WAND_ID = "structurestick:void_filler";
const DISTANCE_WAND_ID = "structurestick:distance_ruler";
const VOLUME_WAND_ID = "structurestick:volume_ruler";
// Store positions per-player
const selections = new Map();

function getRegionSize(pos1, pos2) {
  const dx = Math.abs(pos2.x - pos1.x) + 1;
  const dy = Math.abs(pos2.y - pos1.y) + 1;
  const dz = Math.abs(pos2.z - pos1.z) + 1;
  return { dx, dy, dz };
}

function getBlockCoords(player, maxDistance = 10) {
  const hit = player.getBlockFromViewDirection({
    maxDistance,
    includeLiquidBlocks: true,
    includePassableBlocks: true,
  });
  return hit ? hit.block.location : null;
}

world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;

  if (!player || !item) return;
  if (item.typeId !== STRUCTURE_WAND_ID) return;

const itemName =
    item.nameTag && item.nameTag.length > 0 ? item.nameTag : item.typeId;

  const coords = getBlockCoords(player);
  if (!coords) {
    player.sendMessage("§cNo block in sight within 10 blocks.");
    return;
  }

  let sel = selections.get(player.name) ?? { pos1: null, pos2: null };

  if (!sel.pos1) {
    sel.pos1 = coords;
    player.sendMessage(
      `§a[Structure Stick] First position set at §b${coords.x}, ${coords.y}, ${coords.z}`
    );
  } else {
    sel.pos2 = coords;
    player.sendMessage(
      `§a[Structure Stick] Second position set at §b${coords.x}, ${coords.y}, ${coords.z}`
    );
    // Build structure save command
    const cmd = `structure save ${itemName} ${sel.pos1.x} ${sel.pos1.y} ${sel.pos1.z} ${sel.pos2.x} ${sel.pos2.y} ${sel.pos2.z}`;
    player.sendMessage(`§c[void] §rcommand sent`);
const { dx, dy, dz } = getRegionSize(sel.pos1, sel.pos2);
    if (dx > 64 || dy > 384 || dz > 64) {
      player.sendMessage(
        `§c[Void Stick] The area is too large, don't exceed 64x384x64 blocks.`
      );
    }
    // Run the command in the player's dimension
    system.run(() => {
      player.dimension.runCommand(cmd)
    });

    // Reset after running
    sel = { pos1: null, pos2: null };
  }

  selections.set(player.name, sel);
});



const lastStructures = new Map();

world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;

  if (!player || !item) return;
  if (item.typeId !== BLAZE_WAND_ID) return;

  // Use custom name (nameTag) if set, otherwise the item type
  const itemName =
    item.nameTag && item.nameTag.length > 0 ? item.nameTag : item.typeId;

  // Remember the structure name for this player
  lastStructures.set(player.name, itemName);

  // Get the block the player is looking at
  const hit = player.getBlockFromViewDirection({
    maxDistance: 10,
    includeLiquidBlocks: true,
    includePassableBlocks: true,
  });

  if (!hit) {
    player.sendMessage("§cNo block in sight within 10 blocks.");
    return;
  }

  const loc = hit.block.location;

  // Build structure load command
  const cmd = `structure load ${itemName} ${loc.x} ${loc.y} ${loc.z}`;
  player.sendMessage(`§c[void] §rcommand sent`);
  // Run the command in the player's dimension
  system.run(() => {
    player.dimension.runCommand(cmd);
  });
});


// Store player selections
const vselections = new Map();

world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;

  if (!player || !item) return;
  if (item.typeId !== VOID_WAND_ID) return;

  const coords = getBlockCoords(player);
  if (!coords) {
    player.sendMessage("§cNo block in sight within 10 blocks.");
    return;
  }

  let sel = vselections.get(player.name) ?? { pos1: null, pos2: null };

  if (!sel.pos1) {
    sel.pos1 = coords;
    player.sendMessage(
      `§a[Void Stick] First position set at §b${coords.x}, ${coords.y}, ${coords.z}`
    );
  } else {
    sel.pos2 = coords;
    player.sendMessage(
      `§a[Void Stick] Second position set at §b${coords.x}, ${coords.y}, ${coords.z}`
    );
    
    
    
    const cmd = `fill ${sel.pos1.x} ${sel.pos1.y} ${sel.pos1.z} ${sel.pos2.x} ${sel.pos2.y} ${sel.pos2.z} minecraft:structure_void replace minecraft:air`;
    player.sendMessage(`§c[void] §rcommand sent`);
const { dx, dy, dz } = getRegionSize(sel.pos1, sel.pos2);
    if (dx > 64 || dy > 384 || dz > 64) {
      player.sendMessage(
        `§c[Void Stick] The area is too large, don't exceed 64x384x64 blocks.`
      );
    }
    // Run the command in the player's dimension
    system.run(() => {
      player.dimension.runCommand(cmd)
    });

    // Reset selection
    sel = { pos1: null, pos2: null };
  }

  vselections.set(player.name, sel);

});





const volumesel = new Map();

world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;

  if (!player || !item) return;
  if (item.typeId !== VOLUME_WAND_ID) return;

  const coords = getBlockCoords(player);
  if (!coords) {
    player.sendMessage("§cNo block in sight within 10 blocks.");
    return;
  }

  let sel = volumesel.get(player.name) ?? { pos1: null, pos2: null };

  if (!sel.pos1) {
    sel.pos1 = coords;
    player.sendMessage(
      `§3[Volume ruler] First position set at §b${coords.x}, ${coords.y}, ${coords.z}`
    );
  } else {
    sel.pos2 = coords;
    player.sendMessage(
      `§3[Volume ruler] Second position set at §b${coords.x}, ${coords.y}, ${coords.z}`
    );
const { dx, dy, dz } = getRegionSize(sel.pos1, sel.pos2);
const vol = dx*dy*dz
    player.sendMessage(`The volume of the room is ${vol}`)

    // Reset selection
    sel = { pos1: null, pos2: null };
  }

  volumesel.set(player.name, sel);

});




const distesel = new Map();

world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;

  if (!player || !item) return;
  if (item.typeId !== DISTANCE_WAND_ID) return;

  const coords = getBlockCoords(player);
  if (!coords) {
    player.sendMessage("§cNo block in sight within 10 blocks.");
    return;
  }

  let sel = distesel.get(player.name) ?? { pos1: null, pos2: null };

  if (!sel.pos1) {
    sel.pos1 = coords;
    player.sendMessage(
      `§3[Volume ruler] First position set at §b${coords.x}, ${coords.y}, ${coords.z}`
    );
  } else {
    sel.pos2 = coords;
    player.sendMessage(
      `§3[Volume ruler] Second position set at §b${coords.x}, ${coords.y}, ${coords.z}`
    );

const dx = sel.pos2.x - sel.pos1.x;
    const dy = sel.pos2.y - sel.pos1.y;
    const dz = sel.pos2.z - sel.pos1.z;


    const euclidean = Math.sqrt(dx * dx + dy * dy + dz * dz).toFixed(2);

    player.sendMessage(
      `§e[Distance Wand] X=${dx}, Y=${dy}, Z=${dz}\n` +
      `Distance: §b${euclidean}`
    );

    // Reset selection
    sel = { pos1: null, pos2: null };
  }

  distesel.set(player.name, sel);

});